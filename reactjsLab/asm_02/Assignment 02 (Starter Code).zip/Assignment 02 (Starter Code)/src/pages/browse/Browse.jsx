import React from 'react';

function Browse() {
	return (
		<div className="app">
			<h1>Browse</h1>
		</div>
	);
}

export default Browse;

