import React from 'react';

const Search = () => {
	return (
		<div className='app'>
			<h1>Search</h1>
		</div>
	);
};

export default Search;
